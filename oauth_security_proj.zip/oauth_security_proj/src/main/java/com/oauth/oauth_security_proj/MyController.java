package com.oauth.oauth_security_proj;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyController {
	
	@GetMapping("/")
	public String sayHello()
	{
		return "Hey!!! Welcome You are AUthenticated through GITHUb using OAUTH2.0";
	}

}

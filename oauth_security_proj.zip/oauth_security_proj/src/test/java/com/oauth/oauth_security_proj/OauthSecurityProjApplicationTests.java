package com.oauth.oauth_security_proj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OauthSecurityProjApplicationTests {

	@Test
	void contextLoads() {
	}

}

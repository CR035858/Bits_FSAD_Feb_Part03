import {render,fireEvent,screen} from '@testing-library/react';
import Counter from '../Counter';
import renderer from 'react-test-renderer'
import React from 'react';
/*
test ('increments counter',() => {
    //Render Component in the virtual dom
    render(<Counter />)

    //select  elements to interact
    const counter = screen.getByTestId('counter')
    const incrementBtn = screen.getByTestId('increment')

    //trigger events and test

    fireEvent.click(incrementBtn);
    expect(counter).toHaveTextContent("2");
}); */ 

 
describe('Counter' , () =>{

    it('should increment Counter',()=>{
        //Render Component in the virtual dom
    render(<Counter />)

    //select  elements to interact
    const counter = screen.getByTestId('counter')
    const incrementBtn = screen.getByTestId('increment')

    //trigger events and test

    fireEvent.click(incrementBtn);
    expect(counter).toHaveTextContent("2");
    });

    it('should decrement Counter',()=>{
        //Render Component in the virtual dom
    render(<Counter />)

    //select  elements to interact
    const counter = screen.getByTestId('counter')
    const decrementBtn = screen.getByTestId('decrement')

    //trigger events and test

    fireEvent.click(decrementBtn);
    expect(counter).toHaveTextContent("0");
    });

});/* */
/*
describe ('Counter SnapShot ',() => {
it('should match DOM Snapshot',()=>{
    const tree = renderer.create(<Counter />).toJSON();
    expect(tree).toMatchSnapshot();
});
});*/
